<?php
/**
 * Plugin Name: Webstudio Lab Rotate Pics
 * Plugin URI: http://www.mywebsite.com
 * Description: Custom modules for the Beaver Builder Plugin.
 * Version: 1.0
 * Author: Katerina Elgina
 * Author URI: http://www.mywebsite.com
 */
define( 'WSL_MODULE_ROTATES_DIR', plugin_dir_path( __FILE__ ) );
define( 'WSL_MODULE_ROTATES_URL', plugins_url( '/', __FILE__ ) );

function load_module_rotate_pics() {
    if ( class_exists( 'FLBuilder' ) ) {
        require_once 'rotate-pics/rotate-pics.php';
    }
}
add_action( 'init', 'load_module_rotate_pics' );