<?php
/**
 * This is a module that includs links, images and text fields
 * setup necessary to get it working..
 *
 * @class flRotatePicsModule
 */
class FLRotatePics extends FLBuilderModule
{
    
    /**
     * Constructor function for the module. You must pass the
     * name, description, dir and url in an array to the parent class.
     *
     * @method __construct
     */
    public function __construct()
    {
        parent::__construct(array(
            'name' => __('Rotate pics', 'fl-builder'),
            'description' => __('Add actions for images on your site with the rotate module.', 'fl-builder'),
            'category' => __('WSL', 'fl-builder'),
            'dir' => WSL_MODULE_ROTATES_DIR . 'rotate-pics/',
            'url' => WSL_MODULE_ROTATES_URL . 'rotate-pics/',
            'editor_export' => true,
            'enabled' => true,
            'partial_refresh' => true
        ));
    }
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('FLRotatePics', array(
    'general' => array( // Tab
        'title' => __('General', 'fl-builder'), // Tab title
        'sections' => array( // Tab Sections
            'general' => array( // Section
                'title' => __('Rotate pics', 'fl-builder'), // Section Title
                'fields' => array( // Section Fields
                    
                    'weightpic' => array(
                        'type' => 'text',
                        'label' => __('Weight', 'fl-builder'),
                        'default' => '500',
                        'maxlength' => '4',
                        'size' => '5',
                        'description' => 'px'
                    ),
                    'heightpic' => array(
                        'type' => 'text',
                        'label' => __('Height', 'fl-builder'),
                        'default' => '500',
                        'maxlength' => '4',
                        'size' => '5',
                        'description' => 'px'
                    ),
                    
                    'my_link_field' => array(
                        'type' => 'link',
                        'label' => __('Link Field', 'fl-builder'),
                        'default' => 'http://webstudiolab.it/'
                    )
                )
            ),
            /**
            * Settings for face.
            */
            'formatting' => array(
                'title' => __('Face module content', 'fl-builder'),
                'fields' => array(
                    
                    'rotatepics_field_faceimg' => array(
                        'type' => 'photo',
                        'label' => __('Add your Face Image', 'fl-builder'),
                        'show_remove' => true,
                        'show_reset' => true
                    ),
    
                    'my_photo_field_bgrp_face' => array(
                        'type' => 'color',
                        'label' => __('Background', 'fl-builder'),
                        'default' => 'fffff',
                        'show_reset' => true
                    ),
                    'r_textarea_field_color_h1' => array(
                        'type' => 'color',
                        'label' => __('Header Text Color', 'fl-builder'),
                        'default' => 'fffff',
                        'show_reset' => true
                    ),
                    'r_textarea_field_color' => array(
                        'type' => 'color',
                        'label' => __('Text Color', 'fl-builder'),
                        'default' => 'fffff',
                        'show_reset' => true
                    ),
                    
                    
                    'textarea_field' => array(
                        'type' => 'textarea',
                        'label' => __('Textarea Field', 'fl-builder'),
                        'default' => '',
                        'placeholder' => __('Hook the client with a nice frase', 'fl-builder'),
                        'rows' => '6',
                        'color' => 'ffffff',
                        'preview' => array(
                            'type' => 'text',
                            'selector' => '.fl-example-text'
                        )
                    ),
                    'textarea_field2' => array(
                        'type' => 'textarea',
                        'label' => __('Textarea Field', 'fl-builder'),
                        'default' => '',
                        'placeholder' => __('Describe your idea here', 'fl-builder'),
                        'rows' => '6',
                        'color' => 'ffffff',
                        'preview' => array(
                            'type' => 'text',
                            'selector' => '.fl-example-text'
                        )
                    )
                )
            ),
            /**
            * Settings for back.
            */
            'formatting2' => array(
                'title' => __('Back module content', 'fl-builder'),
                'fields' => array(
                    'rotatepics_field_backimg' => array(
                        'type' => 'photo',
                        'label' => __('Add your Back Image', 'fl-builder'),
                        'show_remove' => true,
                        'show_reset' => true
                    ),
                    'my_photo_field_bgrp_back' => array(
                        'type' => 'color',
                        'label' => __('Background back', 'fl-builder'),
                        'default' => 'fffff',
                        'show_reset' => true
                    ),
                    'r_textarea_field_color_backimg_h1' => array(
                        'type' => 'color',
                        'label' => __('Header Text Color', 'fl-builder'),
                        'default' => 'fffff',
                        'show_reset' => true
                    ),
                    'r_textarea_field_color_backimg' => array(
                        'type' => 'color',
                        'label' => __('Text Color', 'fl-builder'),
                        'default' => 'fffff',
                        'show_reset' => true
                    ),
                    'textarea_field_backimg' => array(
                        'type' => 'textarea',
                        'label' => __('Textarea Field', 'fl-builder'),
                        'default' => '',
                        'placeholder' => __('Hook the client with a nice frase', 'fl-builder'),
                        'rows' => '6',
                        'color' => 'ffffff',
                        'preview' => array(
                            'type' => 'text',
                            'selector' => '.fl-example-text'
                        )
                    ),
                    'textarea_field2_backimg' => array(
                        'type' => 'textarea',
                        'label' => __('Textarea Field', 'fl-builder'),
                        'default' => '',
                        'placeholder' => __('Describe your idea here', 'fl-builder'),
                        'rows' => '6',
                        'color' => 'ffffff',
                        'preview' => array(
                            'type' => 'text',
                            'selector' => '.fl-example-text'
                        )
                    )
                )
            )
        )
        
    )
));
