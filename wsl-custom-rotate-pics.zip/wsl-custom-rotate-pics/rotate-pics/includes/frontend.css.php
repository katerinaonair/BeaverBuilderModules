/**
 * This file should contain frontend styles that
 * will be applied to individual module instances.
 *
 * You have access to three variables in this file:
 *
 * $module An instance of your module class.
 * $id The module's ID.
 * $settings The module's settings.
 * 
 */

.fl-node-<?php echo $id; ?> .fl-rotatepics {
    height: <?php echo $settings->heightpic; ?>px;
    width: <?php echo $settings->weightpic  ?>px;
}
.fl-node-<?php echo $id; ?> .front.face{
    background-color:<?php echo ($settings->my_photo_field_bgrp_face) ? '#'.$settings->my_photo_field_bgrp_face : 'transparent'; ?>;
    color:#<?php echo $settings->r_textarea_field_color; ?>
}
.fl-node-<?php echo $id; ?> .front.face h2{
    color:#<?php echo $settings->r_textarea_field_color_h1; ?>
}

.fl-node-<?php echo $id; ?> .face.back{
    background-color:<?php echo ($settings->my_photo_field_bgrp_back) ? '#'.$settings->my_photo_field_bgrp_back : 'transparent'; ?>;
    color:#<?php echo $settings->r_textarea_field_color_backimg; ?>
}
.fl-node-<?php echo $id; ?> .face.back h2{
    color:#<?php echo $settings->r_textarea_field_color_backimg_h1; ?>
}
  