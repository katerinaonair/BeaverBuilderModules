<?php

/**
 * This file should be used to render each module instance.
 * You have access to two variables in this file:
 *
 * $module An instance of your module class.
 * $settings The module's settings.
 *
 *
 */

?>
<div class="fl-rotatepics">
<div class="grid">
<a href="<?php echo $settings->my_link_field; ?>">
<div  class="f1_container hover" >
  <div  class="f1_card">
    <div class="front face" >  
              <?php printf (   '<img src="%s" border="0">', $settings->rotatepics_field_faceimg_src );?>
                <p> <h2><?php echo $settings->textarea_field; ?></h2>
                        <?php echo $settings->textarea_field2; ?></p>
             
    </div>
    <div  class="back face center hover" >
             <?php printf (   '<img src="%s" border="0">', $settings->rotatepics_field_backimg_src );?>
              <p><h2><?php echo $settings->textarea_field_backimg; ?></h2>
                    <?php echo $settings->textarea_field2_backimg; ?></p>
            
    </div>
    </div>
</div>
</a>
</div>
</div>
