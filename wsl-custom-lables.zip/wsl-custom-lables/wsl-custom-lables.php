<? /**
 * Plugin Name: Webstudio Lab Lables Module
 * Plugin URI: http://bb.webstudiolab.com/webstudiolab-for-bb-plugin/
 * Description: Webstudio Lab modules the Beaver Builder Plugin.
 * Version: 1.0
 * Author: Katerina Elgina
 * Author URI: http://bb.webstudiolab.com/webstudiolab-for-bb-plugin/
 */
define( 'WSL_LABLE_MODULES_DIR', plugin_dir_path( __FILE__ ) );
define( 'WSL_LABLE_MODULES_URL', plugins_url( '/', __FILE__ ) );

function wsl_load_module_lables() {
    if ( class_exists( 'FLBuilder' ) ) {
         require_once 'wsl-lables/wsl-lables.php';
    }
}
add_action( 'init', 'wsl_load_module_lables' );