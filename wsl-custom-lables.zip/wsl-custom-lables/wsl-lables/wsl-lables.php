<?

class WslLablesClass extends FLBuilderModule
{
    
    public function __construct()
    {
        parent::__construct(array(
            'name' => __('WSL Lables', 'fl-builder'),
            'description' => __('Cool lables module!', 'fl-builder'),
            'category' => __('WSL', 'fl-builder'),
            'dir' => WSL_LABLE_MODULES_DIR . 'wsl-lables/',
            'url' => WSL_LABLE_MODULES_URL . 'wsl-lables/',
            'editor_export' => true,
            'enabled' => true,
            'partial_refresh' => false
        ));
        $this->add_css('wsl-lables', $this->url . 'css/frontend.css');
    }
    
    public function get_label_classname()
    {
        
        $classname = '';
        if ($this->settings->banner_type && $this->settings->banner_type == "ribbon2") {
            $classname = 'ribbon2';
        } else if ($this->settings->banner_type && $this->settings->banner_type == "ribbon3") {
            $classname = 'ribbon3';
        } else if ($this->settings->banner_type && $this->settings->banner_type == "ribbon4") {
            $classname = 'ribbon4';
        } else {
            $classname = 'ribbon1';
        }
        
        return $classname;
    }
    
}



/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('WslLablesClass', array(
    'general' => array( // Tab
        'title' => __('General', 'fl-builder'), // Tab title
        'sections' => array( // Tab Sections
            'general' => array( // Section
                'title' => __('Action pics', 'fl-builder'), // Section Title
                'fields' => array( // Section Fields
                    
                    
                    'my_photo_field' => array(
                        'type' => 'photo',
                        'label' => __('Photo Field', 'textdomain'),
                        'show_remove' => false
                    ),
                    
                    'textarea_field' => array(
                        'type' => 'textarea',
                        'label' => __('Textarea Field', 'fl-builder'),
                        'default' => '',
                        'placeholder' => __('Placeholder Text', 'fl-builder'),
                        'rows' => '6',
                        'preview' => array(
                            'type' => 'text',
                            'selector' => '.fl-example-text'
                        )
                    ),
                    
                    'textarea_field_color' => array(
                        'type' => 'color',
                        'label' => __('Text Color', 'fl-builder'),
                        'default' => 'fffff',
                        'show_reset' => true
                    ),
                    
                    'text_size' => array(
                        'type' => 'text',
                        'label' => __('Font Size', 'fl-builder'),
                        'default' => '14',
                        'maxlength' => '3',
                        'size' => '4',
                        'description' => 'px'
                    ),
                    'banner_link_field' => array(
                        'type' => 'link',
                        'label' => __('Link Field', 'fl-builder'),
                        'default' => 'http://webstudiolab.it/'
                    )
                )
            )
            
        )
    ),
    'banner_style' => array(
        'title' => __('Banners Style', 'fl-builder'),
        'sections' => array(
            'card_style' => array(
                'title' => __('Banner Style', 'fl-builder'),
                'fields' => array(
                    
                    'banner_type' => array(
                        'type' => 'select',
                        'label' => __('Banner type', 'fl-builder'),
                        'default' => 'Label 1',
                        'options' => array(
                            'ribbon1' => __('Label 1', 'fl-builder'),
                            'ribbon2' => __('Label 2', 'fl-builder'),
                            'ribbon3' => __('Label 3', 'fl-builder'),
                            'ribbon4' => __('Label 4', 'fl-builder')
                        ),
                        'toggle' => array(
                            'ribbon1' => array(
                                'sections' => array(
                                    'ribbon1'
                                )
                            ),
                            'ribbon2' => array(
                                'sections' => array(
                                    'ribbon2'
                                )
                            ),
                            'ribbon3' => array(
                                'sections' => array(
                                    'ribbon3'
                                )
                            ),
                            'ribbon4' => array(
                                'sections' => array(
                                    'ribbon4'
                                )
                            )
                            
                        )
                        
                    ),
                    
                    
                    'banner_field_color' => array(
                        'type' => 'color',
                        'label' => __('Background Color', 'fl-builder'),
                        'default' => 'c0c0c0',
                        'show_reset' => true
                    ),
                   
                    
                    'label_color_border' => array(
                        'type' => 'color',
                        'label' => __('Border color', 'fl-builder'),
                        'default' => 'C1C3D1',
                        'show_reset' => true
                    ),
                    
                    'label_height_border' => array(
                        'type' => 'text',
                        'label' => __('Border Weight', 'fl-builder'),
                        'default' => '1',
                        'maxlength' => '2',
                        'size' => '3',
                        'description' => 'px',
                        'preview' => array(
                            'type' => 'css',
                            'selector' => '.fl-separator',
                            'property' => 'border-top-width',
                            'unit' => 'px'
                        )
                    ),
                    
                    'label_style_border' => array(
                        'type' => 'select',
                        'label' => __('Style', 'fl-builder'),
                        'default' => 'solid',
                        'options' => array(
                            'solid' => _x('Solid', 'Border type.', 'fl-builder'),
                            'dashed' => _x('Dashed', 'Border type.', 'fl-builder'),
                            'dotted' => _x('Dotted', 'Border type.', 'fl-builder')
                        ),
                        'preview' => array(
                            'type' => 'css',
                            'selector' => '.fl-separator',
                            'property' => 'border-top-style'
                        ),
                        'help' => __('The type of border to use. Double borders must have a height of at least 3px to render properly.', 'fl-builder')
                    )
                    
                    
                )
            ),
            
            
            'ribbon1' => array(
                'title' => __('Label 1', 'fl-builder'),
                'fields' => array(
                    'widthribbon1' => array(
                        'type' => 'text',
                        'label' => __('Width ribbon1', 'fl-builder'),
                        'default' => '70',
                        'maxlength' => '4',
                        'size' => '5',
                        'description' => 'px'
                    )
                )
            ),
            'ribbon2' => array(
                'title' => __('Label 2', 'fl-builder'),
                'fields' => array(
                    'banner_coner_color' => array(
                        'type' => 'color',
                        'label' => __('Corner Color', 'fl-builder'),
                        'default' => 'c0c0c0',
                        'show_reset' => true
                    ),
                     'banner_shadow_color' => array(
                        'type' => 'color',
                        'label' => __('Shadow Color', 'fl-builder'),
                        'default' => 'c0c0c0',
                        'show_reset' => true
                    ),
                    
                )
            ),
            'ribbon3' => array(
                'title' => __('Label 3', 'fl-builder'),
                'fields' => array(
                     'banner_shadow_color' => array(
                        'type' => 'color',
                        'label' => __('Shadow Color', 'fl-builder'),
                        'default' => 'c0c0c0',
                        'show_reset' => true
                    ),
                    
                )
            ),
            'ribbon4' => array(
                'title' => __('Label 4', 'fl-builder'),
                'fields' => array(
                     'banner_shadow_color' => array(
                        'type' => 'color',
                        'label' => __('Shadow Color', 'fl-builder'),
                        'default' => 'c0c0c0',
                        'show_reset' => true
                    ),
                    
                )
            )
            
        )
    )
    
    
    
    
    
));
