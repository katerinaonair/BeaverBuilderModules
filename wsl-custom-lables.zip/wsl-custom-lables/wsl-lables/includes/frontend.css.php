
.fl-node-<?php echo $id; ?> span.ribbon1.ribbon{
    background-color:<?php echo ($settings->banner_field_color) ? '#'.$settings->banner_field_color : 'transparent'; ?>;
    background:<?php echo ($settings->banner_field_color) ? '#'.$settings->banner_field_color : 'transparent'; ?>;
    color:<?php echo ($settings->textarea_field_color) ? '#'.$settings->textarea_field_color : 'transparent'; ?>;
    border:<?php echo $settings->label_height_border; ?>px <?php echo $settings->label_style_border; ?> #<?php echo $settings->label_color_border; ?>;
    width: <?php echo $settings->widthribbon1  ?>px;
}


.fl-node-<?php echo $id; ?> span.ribbon2.ribbon{
    background-color:<?php echo ($settings->banner_field_color) ? '#'.$settings->banner_field_color : 'transparent'; ?>;
    color:<?php echo ($settings->textarea_field_color) ? '#'.$settings->textarea_field_color : 'transparent'; ?>;
    border:<?php echo $settings->label_height_border; ?>px <?php echo $settings->label_style_border; ?> #<?php echo $settings->label_color_border; ?>;
    align: <?php echo $settings->label_align; ?>;
    border-left: #<?php echo $settings->label_color_border; ?>;
}
.fl-node-<?php echo $id; ?> .ribbon2:before{
    border-bottom: 8px solid #<?php echo $settings->banner_shadow_color; ?>;
}
.fl-node-<?php echo $id; ?> .ribbon2:after {
    border-left: 15px solid #<?php echo $settings->banner_coner_color; ?>;
}

.fl-node-<?php echo $id; ?> span.ribbon3.ribbon{
    background-color:<?php echo ($settings->banner_field_color) ? '#'.$settings->banner_field_color : 'transparent'; ?>;
    color:<?php echo ($settings->textarea_field_color) ? '#'.$settings->textarea_field_color : 'transparent'; ?>;
    border:<?php echo $settings->label_height_border; ?>px <?php echo $settings->label_style_border; ?> #<?php echo $settings->label_color_border; ?>;
    align: <?php echo $settings->label_align; ?>;
}

.fl-node-<?php echo $id; ?> .ribbon3:before,
.fl-node-<?php echo $id; ?> .ribbon3:after {
  border-top: 10px solid #<?php echo $settings->banner_shadow_color; ?>;
}
 
.fl-node-<?php echo $id; ?> span.ribbon4.ribbon{
    background-color:<?php echo ($settings->banner_field_color) ? '#'.$settings->banner_field_color : 'transparent'; ?>;
    color:<?php echo ($settings->textarea_field_color) ? '#'.$settings->textarea_field_color : 'transparent'; ?>;
    border:<?php echo $settings->label_height_border; ?>px <?php echo $settings->label_style_border; ?> #<?php echo $settings->label_color_border; ?>;
    align: <?php echo $settings->label_align; ?>;
}

.fl-node-<?php echo $id; ?> .ribbon4 {
  box-shadow:0 0 0 3px  #<?php echo $settings->banner_shadow_color; ?>;  0px 21px 5px -18px rgba(0,0,0,0.6);
}