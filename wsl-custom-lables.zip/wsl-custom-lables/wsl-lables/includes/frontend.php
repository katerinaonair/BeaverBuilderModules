<?php

/**
 * This file should be used to render each module instance.
 * You have access to two variables in this file:
 *
 * $module An instance of your module class.
 * $settings The module's settings.
 *
 */

?>
<div class="fl-labels">
  <div class="wrapper-img">
    <a href="<?php echo $settings->banner_link_field; ?>">
      <div class="banner-wrapper" >
      <?php printf ('<img src="%s" border="0">', $settings->my_photo_field_src );?>
      
        <span class="<?php echo $module->get_label_classname(); ?> ribbon">
        <span class='<?php echo $settings->banner_link_field; ?>'>

          <span>
            <?php echo $settings->textarea_field; ?>
          </span>
          </span>
        </span>
  </div>
</a>
</div>
</div>
